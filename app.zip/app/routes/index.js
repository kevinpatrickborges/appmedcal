import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { TransitionPresets } from '@react-navigation/stack';

import Welcome from '../src/pages/Welcome/index';
import Main from '../src/pages/Main/index';
import Compras from '../src/pages/Compras/index';
import ProductDetails from '../src/pages/Main/ProductDetails';
import Favoritos from '../src/pages/Favoritos/index';
import Notifica from '../src/pages/Notifica/index';
import Mais from '../src/pages/Mais/index';
import PromotionDetails from '../src/pages/Main/PromotionDetails';
import ReagentDetailsWiener from '../src/pages/Reagentes/Wiener/index';
import ReagentDetailsLaborlab from '../src/pages/Reagentes/Laborlab/index';
import ReagentDetailsApparat from '../src/pages/Reagentes/Apparat/index';
import TodosReagentes from '../src/pages/Reagentes/Todos/index';
import Pedidos from '../src/pages/Pedidos/index';
import SignIn from '../src/pages/SignIn/index'


const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

export default function Routes() {
  return (
    <Stack.Navigator>
      <Stack.Screen
        name="Welcome"
        component={Welcome}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="Main"
        component={Main}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="Notifica"
        component={Notifica}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="Mais"
        component={Mais}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="Favoritos"
        component={Favoritos}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="Pedidos"
        component={Pedidos}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="Compras"
        component={Compras}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="SignIn"
        component={SignIn}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="ProductDetails"
        component={ProductDetails}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="PromotionDetails"
        component={PromotionDetails}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="ReagentDetailsWiener"
        component={ReagentDetailsWiener}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="ReagentDetailsLaborlab"
        component={ReagentDetailsLaborlab}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="ReagentDetailsApparat"
        component={ReagentDetailsApparat}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="TodosReagentes"
        component={TodosReagentes}
        options={{ headerShown: false }}
      />
      
    </Stack.Navigator>
  );
}
