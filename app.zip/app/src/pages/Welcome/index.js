import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Image
} from 'react-native';

import * as animatable from 'react-native-animatable';
import { useNavigation } from '@react-navigation/native';

const { width, height } = Dimensions.get('window');

export default function Welcome() {
  const navigation = useNavigation();

  return (
    <View style={styles.container}>
      {/* Logo com animação de fade */}
      <animatable.View animation="fadeIn" style={styles.logoContainer}>
        <Image 
          source={require('../../assets/Logo.png')} // Logo com transparência
          style={styles.logo}
          resizeMode="contain"
        />
      </animatable.View>

      {/* Container do formulário com animação de slide-up */}
      <animatable.View delay={500} animation="slideInUp" style={styles.formContainer}>
        <Text style={styles.title}>Bem-vindo à Loja Virtual</Text>
        <Text style={styles.subtitle}>A melhor experiência de compras online</Text>

        {/* Botões de Navegação */}
        <TouchableOpacity 
          style={styles.button}
          onPress={() => navigation.navigate('SignIn')}
        >
          <Text style={styles.buttonText}>Acessar Conta</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={styles.buttonSecondary}
          onPress={() => navigation.navigate('Main')}
        >
          <Text style={styles.buttonText}>Visitar Loja</Text>
        </TouchableOpacity>
      </animatable.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#2C3E50', // Fundo mais escuro, contrastando com a logo
  },
  logoContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: -height * 0.1, // Ajuste negativo para mover a logo para cima
    height: height * 0.999999, // Definindo uma altura fixa para o container da logo
  },
  logo: {
    width: width * 0.7, // Logo maior
    height: undefined,
    aspectRatio: 1,
  },
  formContainer: {
  width: '80%',
  padding: 20,
  backgroundColor: '#FFFFFF', // Fundo branco para o formulário
  borderRadius: 30,
  alignItems: 'center',
  marginTop: height * 0.05, // Ajuste aqui para mover o conteúdo para cima
  marginBottom: 30, // Ajusta o espaçamento inferior para não colar nos botões
  borderBottomLeftRadius: 80, // Bordas mais arredondadas na parte inferior
  borderBottomRightRadius: 80, // Bordas mais arredondadas na parte inferior
  elevation: 10, // Sombra para dar profundidade
},

title: {
  fontSize: 26,
  fontWeight: 'bold',
  color: '#333',
  marginBottom: 10, // Ajusta o espaçamento entre o título e o subtítulo
  fontFamily: 'Roboto',
  textAlign: 'center',
},

subtitle: {
  fontSize: 18,
  color: '#666',
  marginBottom: 20, // Menos espaço entre o subtítulo e os botões
  textAlign: 'center',
},

button: {
  backgroundColor: '#FF6F61', // Cor do botão
  paddingVertical: 15,
  paddingHorizontal: 40,
  borderRadius: 50,
  marginVertical: 10,
  width: '100%',
  alignItems: 'center',
  shadowColor: '#000',
  shadowOffset: { width: 0, height: 4 },
  shadowOpacity: 0.3,
  shadowRadius: 4,
  elevation: 6,
},

buttonSecondary: {
  backgroundColor: '#38A69D', // Cor do botão secundário
  paddingVertical: 15,
  paddingHorizontal: 40,
  borderRadius: 50,
  marginVertical: 10,
  width: '100%',
  alignItems: 'center',
  shadowColor: '#000',
  shadowOffset: { width: 0, height: 4 },
  shadowOpacity: 0.3,
  shadowRadius: 4,
  elevation: 6,
},


  buttonText: {
    color: '#FFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
});
