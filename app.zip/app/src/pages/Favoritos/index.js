import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import Footer from '../../Components/Footer/index'; // Importando o componente Footer

const FavoritesScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      {/* Cabeçalho simplificado com botão de voltar */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color="#2C3E50" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Favoritos</Text>
      </View>

      {/* Conteúdo dos favoritos (substitua pelo seu conteúdo real) */}
      <View style={styles.content}>
        <Text style={styles.contentText}>Aqui vão os seus itens favoritos.</Text>
      </View>

      {/* Barra inferior com Footer */}
      <Footer navigation={navigation} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    backgroundColor: '#FFF',
    paddingVertical: 10, // Menos altura, para um cabeçalho mais compacto
    paddingHorizontal: 20,
    flexDirection: 'row',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0', // Linha abaixo para separar o cabeçalho
  },
  backButton: {
    marginRight: 15, // Mais espaço entre o botão e o título
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#2C3E50', // Cor mais suave para o título
    flex: 1,
    textAlign: 'center', // Título centralizado
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20, // Espaçamento em volta do conteúdo
  },
  contentText: {
    fontSize: 18,
    color: '#333',
    textAlign: 'center', // Alinhamento centralizado do texto
  },
});

export default FavoritesScreen;
