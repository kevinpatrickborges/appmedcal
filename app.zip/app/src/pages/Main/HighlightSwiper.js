import React from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';
import Swiper from 'react-native-swiper';

// Imagens dos slides
import CM260 from '../../assets/CM260.png';
import ZYBIOZ3 from '../../assets/ZYBIOZ3.png';
import PromoImage1 from '../../assets/promo1.png';
import Promovid from '../../assets/Promovid.png';


const HighlightSwiper = () => {
  return (
    <View style={{ height: 200, marginVertical: 20 }}>
      <Text style={styles.title}>Destaques</Text>
      <Swiper
        style={styles.swiper}
        showsButtons={false}
        autoplay={true}
        dotStyle={styles.dot}
        activeDotStyle={styles.activeDot}
      >
        <View style={styles.slide}>
          <Image source={CM260} style={styles.image} />
        </View>
        <View style={styles.slide}>
          <Image source={ZYBIOZ3} style={styles.image} />
        </View>
        <View style={styles.slide}>
          <Image source={PromoImage1} style={styles.image} />
        </View>        
      </Swiper>
    </View>
  );
};

const styles = StyleSheet.create({
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#0056A6',
    marginLeft: 10,
  },
  swiper: {
    marginTop: 10,
  },
  slide: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
  },
  image: {
    width: '90%',
    height: '100%',
    resizeMode: 'contain',
  },
  dot: {
    backgroundColor: 'rgba(0,0,0,0.2)',
    width: 8,
    height: 8,
    borderRadius: 4,
    marginHorizontal: 3,
  },
  activeDot: {
    backgroundColor: '#0056A6',
    width: 8,
    height: 8,
    borderRadius: 4,
    marginHorizontal: 3,
  },
});

export default HighlightSwiper;
