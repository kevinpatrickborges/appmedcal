import React, { useContext } from 'react';
import { View, Text, FlatList, Button, StyleSheet, TouchableOpacity } from 'react-native';
import { CartContext } from '../context/contextcarrinho'; // Ajuste o caminho conforme necessário
import { Ionicons } from 'react-native-vector-icons'; // Importando Ionicons
import Footer from '../../Components/Footer/index'; // Certifique-se de ajustar o caminho do Footer

const CartScreen = ({ navigation }) => {
  const { cart, removeFromCart } = useContext(CartContext); // Use o contexto do carrinho

  const renderItem = ({ item }) => (
    <View style={styles.itemContainer}>
      <View style={styles.itemDetails}>
        <Text style={styles.itemName}>{item.name}</Text>
        <Text style={styles.itemPrice}>R$ {item.price.toFixed(2)}</Text>
      </View>
      <TouchableOpacity onPress={() => removeFromCart(item.id)} style={styles.removeButton}>
        <Text style={styles.removeButtonText}>Remover</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Carrinho de Compras</Text>
      {cart.length === 0 ? (
        <Text style={styles.emptyCartText}>Seu carrinho está vazio.</Text>
      ) : (
        <FlatList
          data={cart}
          renderItem={renderItem}
          keyExtractor={(item) => item.id.toString()}
        />
      )}

      {/* Total estilizado e mais abaixo */}
      <View style={styles.totalContainer}>
        <Text style={styles.totalText}>
          Total: 
        </Text>
        <Text style={styles.totalAmount}>
          R$ {cart.reduce((total, item) => total + item.price, 0).toFixed(2)}
        </Text>
      </View>

      {/* Rodapé adicionado */}
      <Footer navigation={navigation} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF', // Cor suave para o fundo
    padding: 20,
    paddingBottom: 70, // Espaço para o rodapé
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333', // Cor escura para o título
    marginBottom: 20,
  },
  emptyCartText: {
    fontSize: 18,
    color: '#888', // Cor suave para quando o carrinho está vazio
    textAlign: 'center',
    marginTop: 20,
  },
  itemContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd', // Linha suave de separação entre os itens
  },
  itemDetails: {
    flexDirection: 'column',
  },
  itemName: {
    fontSize: 16,
    color: '#333', // Cor do nome do item
    fontWeight: '500',
  },
  itemPrice: {
    fontSize: 14,
    color: '#555', // Cor mais suave para o preço
  },
  removeButton: {
    paddingVertical: 5,
    paddingHorizontal: 15,
    backgroundColor: '#FF6F61', // Cor suave de fundo para o botão
    borderRadius: 5,
  },
  removeButtonText: {
    color: '#FFF',
    fontSize: 14,
  },
  totalContainer: {
    marginTop: 30, // Espaço maior para o total
    alignItems: 'flex-end',
    paddingRight: 20,
    paddingTop: 10, // Pequeno padding extra para separar do conteúdo acima
    borderTopWidth: 1, // Linha de separação sutil
    borderTopColor: '#ddd',
  },
  totalText: {
    fontSize: 18,
    color: '#333', // Cor mais suave para o texto do total
  },
  totalAmount: {
    fontSize: 24, // Tamanho maior para destacar o valor total
    fontWeight: 'bold',
    color: '#FF6F61', // Cor suave para o total final
    marginTop: 5, // Espaço entre o título e o valor
  },
});

export default CartScreen;
