// data/promotionsData.js
import PromoImage1 from '../../../assets/promo1.png';

export const promotionsData = [
  { id: '1', name: 'Creatinina', price: 250.00, image: PromoImage1 },
  { id: '2', name: 'Creatinina', price: 200.00, image: PromoImage1 },
];