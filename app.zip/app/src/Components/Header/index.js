import React from 'react';
import { View, Text, Image, TextInput, StyleSheet, TouchableOpacity } from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';

const Header = ({ navigation }) => {
  return (
    <View style={styles.headerContainer}>
      <View style={styles.topRow}>
        <Image
          source={require('../../assets/logo2.png')}
          style={styles.logo}
        />
        <Text style={styles.welcomeText}>Bem-vindo, Kevin</Text>
        <TouchableOpacity
          style={styles.cartIcon}
          onPress={() => navigation.navigate('Compras')}  // Navega para a página de compras
        >
          <Ionicons name="cart-outline" size={28} color="#FFF" />
        </TouchableOpacity>
      </View>
      <TextInput
        style={styles.searchBar}
        placeholder="O que você procura?"
        placeholderTextColor="#888"
      />
    </View>
  );
};

const styles = StyleSheet.create({
  headerContainer: {
    paddingVertical: 10,
    paddingHorizontal: 10,
    backgroundColor: '#2C3E50', // Cor de fundo mais sofisticada
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.5,
    elevation: 5, // Sombra para iOS e Android
  },
  topRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  logo: {
    width: 60,
    height: 60,
    borderRadius: 10,
  },
  welcomeText: {
    fontSize: 20,
    fontWeight: '600',
    color: '#FFF',
    marginLeft: 15,
    flex: 1,
  },
  cartIcon: {
    padding: 10,
  },
  searchBar: {
    marginTop: 15,
    padding: 12,
    backgroundColor: '#fff',
    borderRadius: 25,
    borderWidth: 1,
    borderColor: '#ccc',
    fontSize: 16,
    color: '#333',
    elevation: 3,
  },
});

export default Header;
